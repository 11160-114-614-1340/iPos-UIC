package com.project.controller;

import java.security.Principal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.domain.Hashtag;
import com.project.domain.Post;
import com.project.domain.User;
import com.project.domain.UserRole;
import com.project.service.PostService;
import com.project.service.RoleDao;
import com.project.service.UserService;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;

	@Autowired
	private PostService postService;

	@Autowired
	private RoleDao roleDao;

	@RequestMapping("/")
	public String home() {
		return "redirect:/index";
	}

	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public String signup(Model model) {
		User user = new User();

		model.addAttribute("user", user);

		return "signup";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public String signupPost(@ModelAttribute("user") User user, Model model) {

		if (userService.checkUserExists(user.getUsername(), user.getEmail())) {

			if (userService.checkEmailExists(user.getEmail())) {
				model.addAttribute("emailExists", true);
			}

			if (userService.checkUsernameExists(user.getUsername())) {
				model.addAttribute("usernameExists", true);
			}

			return "signup";
		} else {
			Set<UserRole> userRoles = new HashSet<>();
			userRoles.add(new UserRole(user, roleDao.findByName("ROLE_USER")));

			userService.createUser(user, userRoles);

			return "redirect:/";
		}
	}

	@RequestMapping("/homePage")
	public String homePage(Principal principal, Model model, @PageableDefault(size = 5) Pageable pageRequest) {
		User user = userService.findByUsername(principal.getName());
		Post post = new Post();
		Page<Post> posts = postService.findAll(pageRequest);
		PageWrapper<Post> page = new PageWrapper<Post>(posts, "/homePage");
		List<User> listUsers = userService.findUserList();

		model.addAttribute("user", user);

		model.addAttribute("post", post);
		model.addAttribute("posts", posts);
		model.addAttribute("page", page);
		model.addAttribute("users", listUsers);
		return "homePage";
	}

	@RequestMapping(value = "/homePage", method = RequestMethod.POST)
	public String homePost(@ModelAttribute("post") Post post, Model model) {

		postService.createPost(post);
		return "redirect:/homePage";
	}

	@RequestMapping(value = "/homePage/delete", method = RequestMethod.GET)
	public String homeDelete(@RequestParam(value = "postId") long postId, Model model, Principal principal) {
		User user = userService.findByUsername(principal.getName());
		List<Post> posts = postService.findAll();
		for (Post post : posts) {
			if (user.getUserId() == post.getUserId() && postId == post.getPostId()) {
				postService.deletePostByPostId(postId);
			}
		}

		return "redirect:/homePage";
	}

	@RequestMapping(value = "/myPost", method = RequestMethod.GET)
	public String myPost(Model model, Principal principal, @PageableDefault(size = 5) Pageable pageRequest) {

		User user = userService.findByUsername(principal.getName());
		Page<Post> posts = postService.findByUserId(user.getUserId(), pageRequest);
		PageWrapper<Post> page = new PageWrapper<Post>(posts, "/myPost");
		model.addAttribute("user", user);
		model.addAttribute("posts", posts);
		model.addAttribute("page", page);

		return "myPost";
	}

	@RequestMapping(value = "/myPost/delete", method = RequestMethod.GET)
	public String myPostDelete(@RequestParam(value = "postId") long postId, Model model, Principal principal) {

		User user = userService.findByUsername(principal.getName());
		List<Post> posts = postService.findByUserId(user.getUserId());
		for (Post post : posts) {
			if (user.getUserId() == post.getUserId() && postId == post.getPostId()) {
				postService.deletePostByPostId(postId);
			}
		}
		model.addAttribute("user", user);
		model.addAttribute("posts", posts);

		return "redirect:/myPost";
	}

	@RequestMapping(value = "/showPage/username", method = RequestMethod.GET)
	public String showPostUser(@RequestParam(value = "username") String username, Model model,
			@PageableDefault(size = 5) Pageable pageRequest, Principal principal) {
		String flagName = principal.getName();
		User user = userService.findByUsername(username);
		Page<Post> posts = postService.findByUserId(user.getUserId(), pageRequest);
		if (user.getUsername().equals(flagName)) {
			PageWrapper<Post> page = new PageWrapper<Post>(posts, "/myPost");
			model.addAttribute("page", page);
			model.addAttribute("user", user);

			model.addAttribute("posts", posts);

			return "redirect:/myPost";

		} else {
			PageWrapper<Post> page = new PageWrapper<Post>(posts, "/showPage");
			model.addAttribute("page", page);
			model.addAttribute("user", user);

			model.addAttribute("posts", posts);
			return "showPage";
		}

	}

	@RequestMapping(value = "/homePage/search")
	public Hashtag Search(@RequestParam(value = "HashtagNameSearch") String pSearchTerm, HttpServletRequest request,
			HttpServletResponse response) {
		Hashtag search = new Hashtag();
		search.getHashtagName();
		return search;
	}

}
