package com.project.service;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.project.domain.Hashtag;

public interface HashtagDao extends CrudRepository<Hashtag, Long> {
	List<Hashtag> findByHashtagNameLike(String hashtagName);
}
