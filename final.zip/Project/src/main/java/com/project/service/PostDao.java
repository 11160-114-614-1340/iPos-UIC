package com.project.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.project.domain.Post;

public interface PostDao extends CrudRepository<Post, Long>{
	//List<Post> findByHashtagId(String hastagId);
	List<Post> findAll();
	Page<Post> findAll(Pageable pageRequest);
	List<Post> findByUserId(long userId);
	Page<Post> findByUserId(long userId, Pageable pageRequest);
	void deleteByPostId(long postId);
	void deleteByUserId(long userId);

}
