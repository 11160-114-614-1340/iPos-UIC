package com.userfront.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Hashtag {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "hashtagId", nullable = false, unique = true)
	private long hashtagId;
	
	private String hashtagName;
	
//	@OneToMany(mappedBy = "Hashtag", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
//    @JsonIgnore
//    private List<Hashtag> hashtagList;

	public long getHashtagId() {
		return hashtagId;
	}

	public void setHashtagId(long hashtagId) {
		this.hashtagId = hashtagId;
	}

	public String getHashtagName() {
		return hashtagName;
	}

	public void setHashtagName(String hashtagName) {
		this.hashtagName = hashtagName;
	}

//	public List<Hashtag> getHashtagList() {
//		return hashtagList;
//	}

//	public void setHashtagList(List<Hashtag> hashtagList) {
//		this.hashtagList = hashtagList;
//	}
    
    
}
