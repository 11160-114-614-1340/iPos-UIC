package com.userfront.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Post {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "postId", nullable = false, updatable = false)
	private Long postId;
	
	private Long userId;
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "hashtagId", nullable = false, unique = false)
	private Long hashtagId;
	
	private String postContent;
	public Long getPostId() {
		return postId;
	}
	public void setPostId(Long postId) {
		this.postId = postId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getHashtagId() {
		return hashtagId;
	}
	public void setHashtagId(Long hashtagId) {
		this.hashtagId = hashtagId;
	}
	public String getPostContent() {
		return postContent;
	}
	public void setPostContent(String postContent) {
		this.postContent = postContent;
	}
	
	
	

}
