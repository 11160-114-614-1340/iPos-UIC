package com.userfront.service;

import java.util.List;

import com.userfront.domain.Post;

public interface PostService {
	Post createPost(Post post);
	 void save (Post post);
	 List<Post> findAll();
}
