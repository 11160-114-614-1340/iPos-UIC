package com.userfront.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.userfront.domain.Post;

public interface PostDao extends CrudRepository<Post, Long> {
	//List<Post> findByHashtagId(String hastagId);
	List<Post> findAll();
	void deleteByPostId(long postId);
	void deleteByUserId(long userId);

}
