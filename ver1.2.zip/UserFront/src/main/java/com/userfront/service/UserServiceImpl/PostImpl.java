package com.userfront.service.UserServiceImpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.userfront.dao.PostDao;
import com.userfront.domain.Post;
import com.userfront.service.PostService;
import com.userfront.service.UserService;

@Service
@Transactional
public class PostImpl implements PostService {
private static final Logger LOG = LoggerFactory.getLogger(UserService.class);
	
	@Autowired
	private PostDao postDao;

	@Override
	public Post createPost(Post post) {
		long hashtagId = 23;
		post.setHashtagId(hashtagId);
		//post.setPostId(hashtagId);
		//post.setUserId("123");
		
		Post localPost = new Post();
		localPost = postDao.save(post);
		return localPost;
	}

	@Override
	public void save(Post post) {
		postDao.save(post);
		
	}
	public Post savePost (Post post) {
        return postDao.save(post);
    }

	@Override
	public List<Post> findAll() {
		// TODO Auto-generated method stub
		return postDao.findAll();
	}

	@Override
	public void deletePostByPostId(long postId) {
		// TODO Auto-generated method stub
	postDao.deleteByPostId(postId);
		
	}

	@Override
	public void deletePostByUserId(long userId) {
		// TODO Auto-generated method stub
		postDao.deleteByUserId(userId);
		
	}

	

    

}
