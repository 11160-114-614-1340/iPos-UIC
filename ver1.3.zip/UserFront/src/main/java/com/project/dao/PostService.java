package com.project.dao;

import java.util.List;

import com.project.domain.Post;

public interface PostService {
	Post createPost(Post post);
	 void save (Post post);
	 List<Post> findAll();
	 void deletePostByPostId(long postId);
	 void deletePostByUserId(long userId);
}
