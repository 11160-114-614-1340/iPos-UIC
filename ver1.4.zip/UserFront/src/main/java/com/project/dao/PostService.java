package com.project.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.project.domain.Post;

public interface PostService {
	Post createPost(Post post);
	 void save (Post post);
	 List<Post> findAll();
	 Page<Post> findAll(Pageable pageRequest);
	 List<Post> findByUserId(long userId);
	 void deletePostByPostId(long postId);
	 void deletePostByUserId(long userId);
}
