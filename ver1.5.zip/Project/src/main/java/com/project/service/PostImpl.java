package com.project.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.dao.PostDao;
import com.project.domain.Post;


@Service
@Transactional
public class PostImpl implements PostService {
private static final Logger LOG = LoggerFactory.getLogger(UserService.class);
	
	@Autowired
	private PostDao postDao;

	@Override
	public Post createPost(Post post) {
		long hashtagId = 23;
		post.setHashtagId(hashtagId);
		//post.setPostId(hashtagId);
		//post.setUserId("123");
		
		Post localPost = new Post();
		localPost = postDao.save(post);
		return localPost;
	}

	@Override
	public void save(Post post) {
		postDao.save(post);
		
	}
	public Post savePost (Post post) {
        return postDao.save(post);
    }

	@Override
	public List<Post> findAll() {
		// TODO Auto-generated method stub
		return postDao.findAll();
	}
	
	@Override
	public List<Post> findByUserId(long userId) {
		return postDao.findByUserId(userId);
	}

	@Override
	public void deletePostByPostId(long postId) {
		// TODO Auto-generated method stub
	postDao.deleteByPostId(postId);
		
	}

	@Override
	public void deletePostByUserId(long userId) {
		// TODO Auto-generated method stub
		postDao.deleteByUserId(userId);
		
	}
	@Transactional(readOnly = true)
	@Override
	public Page<Post> findAll(Pageable pageRequest) {
		// TODO Auto-generated method stub
		Page<Post> listPost = postDao.findAll(pageRequest);
		
		 return listPost;
	}
	private Pageable createPageRequest() {
	    return new PageRequest(0, 10);
	}

	@Override
	public Page<Post> findByUserId(long userId, Pageable pageRequest) {
		return postDao.findByUserId(userId, pageRequest);
	}
	



	

    

}
